<?php 
	echo $errors->first('nama')."<br>";
	echo $errors->first('tempat_lahir')."<br>";
	echo $errors->first('alamat')."<br>";
	echo $errors->first('semester')."<br>";
	echo $errors->first('jenis_kelamin')."<br>";
	echo $errors->first('universitas')."<br>";
	echo $errors->first('fakultas')."<br>";
	echo $errors->first('prodi')."<br>";
	echo $errors->first('tanggal_var')."<br>";
	echo $errors->first('bulan_var')."<br>";
	echo $errors->first('tahun_var')."<br>";
	echo $errors->first('username')."<br>";
	echo $errors->first('password')."<br>";

 ?><?php /**PATH C:\xampp\htdocs\Kathink_v3\resources\views/uji.blade.php ENDPATH**/ ?>