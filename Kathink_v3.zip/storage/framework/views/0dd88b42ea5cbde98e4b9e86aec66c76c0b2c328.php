<!DOCTYPE html>
<html>
<head>
	<title>KATHINK</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleContactbesar.css')); ?>" media="(min-width: 2400px)">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/stylekecil.css')); ?>" media="(max-width: 2400px)">

</head>
<body>	

<script type="text/javascript">
	function muncul() {
		document.getElementById("tot").style.opacity="1";
	}
</script>
	<div class="main">
		<div class="banner" ><span class="bos" style="font-size: 80px;padding-left: 100px;cursor: pointer;"><a href="kathink">KATHINK</a></span>
			<img src="lion.png" style="height: 200px;width: 200px;position: absolute;top: -30px;left: -70px;">
			<ul>
				<li>login</li>
				<li>registrasi</li>
				<li>universitas</li>
				<li>about</li>
				<li><a href="/contact">contact</a></li>
			</ul>
		</div>
		<font class="fav" style="font-size: 200pt;position: absolute;top: 120px;left: 25%;" id="tot">CONTACT</font>
		<img src="wa.png" style="width: 200px;height: 200px;position: absolute;left: 400px;top: 700px;" onload="muncul()">
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\Kathink_v3\resources\views/contact.blade.php ENDPATH**/ ?>