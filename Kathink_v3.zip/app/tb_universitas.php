<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_universitas extends Model
{
    //
}
