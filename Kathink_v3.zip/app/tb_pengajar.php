<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_pengajar extends Model
{
    //
}
