<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tb_fakultas extends Model
{
    //
}
